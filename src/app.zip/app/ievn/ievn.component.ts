import { Component } from "@angular/core";

@Component({
    selector: 'app-ievn',
    template:`
    <div></div>`
})
export class ievnComponent{
    constructor(){}
}