export interface alumnosIr{
    matricula:number;
    nombre:string;
    edad:number;
    correo:string;
    pago:number;
    foto:string;
    }